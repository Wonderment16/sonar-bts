﻿const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
ctx.imageSmoothingEnabled = false;

const pixelScale = 3;
const pixelCanvas = document.createElement("canvas");
const pixelCtx = pixelCanvas.getContext("2d");
pixelCanvas.width = Math.floor(canvas.width / pixelScale);
pixelCanvas.height = Math.floor(canvas.height / pixelScale);
pixelCtx.imageSmoothingEnabled = false;

const playerSprite = new Image();
playerSprite.src = "player.png";
let playerSpriteReady = false;
playerSprite.onload = () => {
  playerSpriteReady = true;
};

const hudOxygen = document.getElementById("oxygen");
const hudArtifacts = document.getElementById("artifacts");
const hudPing = document.getElementById("ping");
const overlay = document.getElementById("overlay");

const world = {
  width: 960,
  height: 540,
  walls: [
    { x: 0, y: 0, w: 960, h: 20 },
    { x: 0, y: 520, w: 960, h: 20 },
    { x: 0, y: 0, w: 20, h: 540 },
    { x: 940, y: 0, w: 20, h: 540 },

    { x: 120, y: 90, w: 220, h: 36 },
    { x: 520, y: 120, w: 260, h: 30 },
    { x: 180, y: 230, w: 160, h: 30 },
    { x: 420, y: 260, w: 120, h: 36 },
    { x: 640, y: 260, w: 200, h: 28 },
    { x: 110, y: 360, w: 240, h: 36 },
    { x: 420, y: 380, w: 210, h: 30 },
  ],
};

const player = {
  x: 80,
  y: 80,
  r: 12,
  speed: 220,
  vx: 0,
  vy: 0,
  dirX: 1,
  dirY: 0,
  animTime: 0,
};

const monster = {
  x: 860,
  y: 460,
  r: 16,
  speed: 140,
  vx: 0,
  vy: 0,
  target: null,
  wanderTimer: 0,
};

const artifacts = [
  { x: 860, y: 90, r: 10, picked: false },
  { x: 500, y: 470, r: 10, picked: false },
  { x: 260, y: 300, r: 10, picked: false },
];

const exitBeacon = {
  x: 880,
  y: 260,
  r: 16,
  active: false,
};

const bubbles = Array.from({ length: 60 }, () => ({
  x: Math.random() * world.width,
  y: Math.random() * world.height,
  r: 1 + Math.random() * 2.5,
  speed: 10 + Math.random() * 30,
  drift: -0.4 + Math.random() * 0.8,
}));

const caveRocks = [];
const caveDust = [];

let keys = new Set();
let oxygen = 100;
let gameState = "playing"; // playing | win | lose

let pingCooldown = 1.0;
let pingTimer = 0;
let pingDuration = 0.8;
let pingTime = pingDuration;
let pingOrigin = { x: player.x, y: player.y };

function generateCave() {
  const edgeCount = 60;
  const sideCount = 50;
  for (let i = 0; i < edgeCount; i++) {
    caveRocks.push({
      x: Math.random() * world.width,
      y: -30 + Math.random() * 70,
      r: 20 + Math.random() * 60,
    });
    caveRocks.push({
      x: Math.random() * world.width,
      y: world.height - 40 + Math.random() * 80,
      r: 20 + Math.random() * 60,
    });
  }
  for (let i = 0; i < sideCount; i++) {
    caveRocks.push({
      x: -30 + Math.random() * 70,
      y: Math.random() * world.height,
      r: 20 + Math.random() * 60,
    });
    caveRocks.push({
      x: world.width - 40 + Math.random() * 80,
      y: Math.random() * world.height,
      r: 20 + Math.random() * 60,
    });
  }
  for (let i = 0; i < 140; i++) {
    caveDust.push({
      x: Math.random() * world.width,
      y: Math.random() * world.height,
      r: 0.6 + Math.random() * 1.4,
    });
  }
}

generateCave();

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function dist(a, b) {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return Math.hypot(dx, dy);
}

function rectCircleResolve(circle, rect) {
  const closestX = clamp(circle.x, rect.x, rect.x + rect.w);
  const closestY = clamp(circle.y, rect.y, rect.y + rect.h);
  const dx = circle.x - closestX;
  const dy = circle.y - closestY;
  const d = Math.hypot(dx, dy);
  if (d < circle.r) {
    const overlap = circle.r - d;
    const nx = d === 0 ? 1 : dx / d;
    const ny = d === 0 ? 0 : dy / d;
    circle.x += nx * overlap;
    circle.y += ny * overlap;
    return true;
  }
  return false;
}

function moveWithCollision(entity, dt) {
  entity.x += entity.vx * dt;
  entity.y += entity.vy * dt;
  for (const wall of world.walls) {
    rectCircleResolve(entity, wall);
  }
}

function setOverlay(text) {
  overlay.textContent = text;
  overlay.classList.remove("hidden");
}

function hideOverlay() {
  overlay.classList.add("hidden");
}

function onPing() {
  pingTimer = pingCooldown;
  pingTime = 0;
  pingOrigin = { x: player.x, y: player.y };
  monster.target = { x: player.x, y: player.y };
}

function updatePlayer(dt) {
  let dx = 0;
  let dy = 0;
  if (keys.has("ArrowLeft") || keys.has("a")) dx -= 1;
  if (keys.has("ArrowRight") || keys.has("d")) dx += 1;
  if (keys.has("ArrowUp") || keys.has("w")) dy -= 1;
  if (keys.has("ArrowDown") || keys.has("s")) dy += 1;

  const len = Math.hypot(dx, dy) || 1;
  player.vx = (dx / len) * player.speed;
  player.vy = (dy / len) * player.speed;
  if (dx !== 0 || dy !== 0) {
    player.dirX = dx / len;
    player.dirY = dy / len;
  }
  player.animTime += dt * (dx !== 0 || dy !== 0 ? 8 : 2);

  moveWithCollision(player, dt);
}

function updateMonster(dt) {
  if (monster.target) {
    const dirX = monster.target.x - monster.x;
    const dirY = monster.target.y - monster.y;
    const d = Math.hypot(dirX, dirY);
    if (d < 8) {
      monster.target = null;
    } else {
      monster.vx = (dirX / d) * monster.speed;
      monster.vy = (dirY / d) * monster.speed;
    }
  } else {
    monster.wanderTimer -= dt;
    if (monster.wanderTimer <= 0) {
      monster.wanderTimer = 2 + Math.random() * 2;
      const angle = Math.random() * Math.PI * 2;
      monster.vx = Math.cos(angle) * (monster.speed * 0.4);
      monster.vy = Math.sin(angle) * (monster.speed * 0.4);
    }
  }

  moveWithCollision(monster, dt);
}

function updateArtifacts() {
  for (const art of artifacts) {
    if (!art.picked && dist(player, art) < player.r + art.r + 2) {
      art.picked = true;
    }
  }
  const pickedCount = artifacts.filter(a => a.picked).length;
  exitBeacon.active = pickedCount === artifacts.length;
}

function updateExit() {
  if (!exitBeacon.active) return;
  if (dist(player, exitBeacon) < player.r + exitBeacon.r + 4) {
    gameState = "win";
    setOverlay("Escape Achieved");
  }
}

function updateOxygen(dt) {
  oxygen = clamp(oxygen - dt * 6, 0, 100);
  if (oxygen <= 0 && gameState === "playing") {
    gameState = "lose";
    setOverlay("Oxygen Depleted");
  }
}

function updatePing(dt) {
  pingTimer = Math.max(0, pingTimer - dt);
  if (pingTime < pingDuration) pingTime += dt;
}

function updateBubbles(dt) {
  for (const b of bubbles) {
    b.y -= b.speed * dt;
    b.x += b.drift;
    if (b.y < -10) {
      b.y = world.height + 10;
      b.x = Math.random() * world.width;
    }
    if (b.x < -10) b.x = world.width + 10;
    if (b.x > world.width + 10) b.x = -10;
  }
}

function updateHUD() {
  hudOxygen.textContent = `O2: ${Math.ceil(oxygen)}`;
  const pickedCount = artifacts.filter(a => a.picked).length;
  hudArtifacts.textContent = `Artifacts: ${pickedCount}/${artifacts.length}`;
  if (pingTimer <= 0) {
    hudPing.textContent = "Ping: Ready";
  } else {
    hudPing.textContent = `Ping: ${(pingTimer).toFixed(1)}s`;
  }
}

function checkLose() {
  if (dist(player, monster) < player.r + monster.r) {
    gameState = "lose";
    setOverlay("Silenced by the Deep");
  }
}

function drawBackground(g) {
  const bg = g.createRadialGradient(
    world.width * 0.5,
    world.height * 0.45,
    60,
    world.width * 0.5,
    world.height * 0.45,
    world.width * 0.7
  );
  bg.addColorStop(0, "#1b4a7c");
  bg.addColorStop(1, "#0a1c33");
  g.fillStyle = bg;
  g.fillRect(0, 0, world.width, world.height);

  g.fillStyle = "rgba(16, 38, 52, 0.75)";
  for (const rock of caveRocks) {
    g.beginPath();
    g.arc(rock.x, rock.y, rock.r, 0, Math.PI * 2);
    g.fill();
  }

  g.fillStyle = "rgba(26, 82, 108, 0.7)";
  for (const wall of world.walls) {
    g.fillRect(wall.x, wall.y, wall.w, wall.h);
  }

  g.strokeStyle = "rgba(90, 180, 210, 0.6)";
  g.lineWidth = 2;
  for (const wall of world.walls) {
    g.beginPath();
    g.moveTo(wall.x + 4, wall.y + 4);
    g.lineTo(wall.x + wall.w - 6, wall.y + 4);
    g.stroke();
  }

  g.fillStyle = "rgba(120, 210, 235, 0.16)";
  for (const d of caveDust) {
    g.beginPath();
    g.arc(d.x, d.y, d.r, 0, Math.PI * 2);
    g.fill();
  }

  g.fillStyle = "rgba(140, 230, 255, 0.25)";
  for (const b of bubbles) {
    g.beginPath();
    g.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    g.fill();
  }
}

function drawArtifacts(g) {
  for (const art of artifacts) {
    if (art.picked) continue;
    g.save();
    g.translate(art.x, art.y);
    g.fillStyle = "rgba(80, 255, 255, 1)";
    g.fillRect(-5, -14, 10, 28);
    g.fillStyle = "rgba(210, 255, 255, 1)";
    g.fillRect(-7, -18, 14, 8);
    g.restore();

    g.save();
    g.globalCompositeOperation = "lighter";
    g.fillStyle = "rgba(170, 255, 255, 0.45)";
    g.beginPath();
    g.arc(art.x, art.y, 32, 0, Math.PI * 2);
    g.fill();
    g.restore();
  }
}

function drawExit(g) {
  if (!exitBeacon.active) return;
  g.save();
  g.strokeStyle = "rgba(120, 230, 255, 0.9)";
  g.lineWidth = 2;
  g.beginPath();
  g.arc(exitBeacon.x, exitBeacon.y, exitBeacon.r + 6, 0, Math.PI * 2);
  g.stroke();
  g.fillStyle = "rgba(90, 210, 255, 0.4)";
  g.beginPath();
  g.arc(exitBeacon.x, exitBeacon.y, exitBeacon.r, 0, Math.PI * 2);
  g.fill();
  g.restore();
}

function drawPlayer(g) {
  if (playerSpriteReady) {
    const spriteW = 28;
    const spriteH = 36;
    const bob = Math.sin(player.animTime * 1.8) * 0.8;
    g.save();
    g.translate(player.x, player.y + bob);
    const facingLeft = player.dirX < -0.1;
    g.scale(facingLeft ? -1 : 1, 1);
    g.drawImage(playerSprite, -spriteW / 2, -spriteH + 6, spriteW, spriteH);
    g.restore();

    g.save();
    g.globalCompositeOperation = "lighter";
    g.fillStyle = "rgba(80, 230, 255, 0.18)";
    g.beginPath();
    g.arc(player.x, player.y + 2, 20, 0, Math.PI * 2);
    g.fill();
    g.restore();
    return;
  }

  const angle = Math.atan2(player.dirY, player.dirX);
  g.save();
  g.translate(player.x, player.y);
  g.rotate(angle);

  g.fillStyle = "rgba(15, 30, 40, 0.95)";
  g.fillRect(-12, -5, 24, 10);
  g.fillStyle = "rgba(25, 60, 75, 0.95)";
  g.fillRect(-16, -3, 5, 6);
  g.fillStyle = "rgba(45, 100, 125, 0.95)";
  g.fillRect(6, -4, 8, 8);
  g.fillStyle = "rgba(110, 245, 255, 0.95)";
  g.fillRect(-2, -9, 4, 6);
  g.fillStyle = "rgba(190, 255, 255, 0.95)";
  g.fillRect(8, -2, 3, 3);

  g.restore();

  g.save();
  g.globalCompositeOperation = "lighter";
  g.fillStyle = "rgba(80, 230, 255, 0.2)";
  g.beginPath();
  g.arc(player.x, player.y, 18, 0, Math.PI * 2);
  g.fill();
  g.restore();
}

function drawMonster(g) {
  g.save();
  g.translate(monster.x, monster.y);
  g.fillStyle = "rgba(45, 12, 20, 0.98)";
  g.beginPath();
  g.ellipse(0, 0, monster.r + 8, monster.r, 0, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = "rgba(75, 20, 30, 0.9)";
  g.beginPath();
  g.ellipse(6, 0, monster.r + 2, monster.r - 6, 0, 0, Math.PI * 2);
  g.fill();
  g.fillStyle = "rgba(255, 80, 100, 1)";
  g.fillRect(6, -6, 4, 4);
  g.fillRect(6, 2, 4, 4);
  g.restore();

  g.save();
  g.globalCompositeOperation = "lighter";
  g.fillStyle = "rgba(255, 120, 140, 0.3)";
  g.beginPath();
  g.arc(monster.x, monster.y, 30, 0, Math.PI * 2);
  g.fill();
  g.restore();
}

function drawSonar(g) {
  const revealBase = 230;
  g.save();
  g.fillStyle = "rgba(0,0,0,0.22)";
  g.fillRect(0, 0, world.width, world.height);

  g.globalCompositeOperation = "destination-out";
  const grad = g.createRadialGradient(player.x, player.y, 10, player.x, player.y, revealBase);
  grad.addColorStop(0, "rgba(0,0,0,0.28)");
  grad.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grad;
  g.beginPath();
  g.arc(player.x, player.y, revealBase, 0, Math.PI * 2);
  g.fill();

  const angle = Math.atan2(player.dirY, player.dirX);
  const coneLength = 280;
  const coneSpread = Math.PI / 6;
  g.save();
  g.translate(player.x, player.y);
  g.rotate(angle);
  const coneGrad = g.createRadialGradient(0, 0, 30, coneLength, 0, coneLength);
  coneGrad.addColorStop(0, "rgba(0,0,0,0.6)");
  coneGrad.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = coneGrad;
  g.beginPath();
  g.moveTo(0, 0);
  g.arc(0, 0, coneLength, -coneSpread, coneSpread);
  g.closePath();
  g.fill();
  g.restore();

  if (pingTime < pingDuration) {
    const t = pingTime / pingDuration;
    const radius = 30 + t * 380;
    const ring = g.createRadialGradient(pingOrigin.x, pingOrigin.y, radius - 26, pingOrigin.x, pingOrigin.y, radius + 20);
    ring.addColorStop(0, "rgba(0,0,0,0)");
    ring.addColorStop(0.35, "rgba(0,0,0,0.35)");
    ring.addColorStop(0.7, "rgba(0,0,0,0.05)");
    ring.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = ring;
    g.beginPath();
    g.arc(pingOrigin.x, pingOrigin.y, radius + 20, 0, Math.PI * 2);
    g.fill();
  }

  g.restore();

  if (pingTime < pingDuration) {
    const t = pingTime / pingDuration;
    const radius = 30 + t * 380;
    g.save();
    g.globalCompositeOperation = "lighter";
    const glow = g.createRadialGradient(pingOrigin.x, pingOrigin.y, 0, pingOrigin.x, pingOrigin.y, radius);
    glow.addColorStop(0, "rgba(170, 250, 255, 0.65)");
    glow.addColorStop(0.7, "rgba(120, 220, 245, 0.35)");
    glow.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = glow;
    g.beginPath();
    g.arc(pingOrigin.x, pingOrigin.y, radius, 0, Math.PI * 2);
    g.fill();
    g.restore();

    g.save();
    g.strokeStyle = "rgba(120, 255, 255, 0.6)";
    g.lineWidth = 2;
    g.beginPath();
    g.arc(pingOrigin.x, pingOrigin.y, radius, 0, Math.PI * 2);
    g.stroke();
    g.globalAlpha = 0.35;
    g.beginPath();
    g.arc(pingOrigin.x, pingOrigin.y, radius * 0.66, 0, Math.PI * 2);
    g.stroke();
    g.restore();
  }

  const vignette = g.createRadialGradient(
    world.width * 0.5,
    world.height * 0.5,
    80,
    world.width * 0.5,
    world.height * 0.5,
    world.width * 0.75
  );
  vignette.addColorStop(0, "rgba(0,0,0,0)");
  vignette.addColorStop(1, "rgba(0,0,0,0.25)");
  g.fillStyle = vignette;
  g.fillRect(0, 0, world.width, world.height);
}

function drawHUDOverlay(g) {
  const barWidth = 120;
  const barHeight = 8;
  const x = 16;
  const y = 70;

  g.fillStyle = "rgba(5, 10, 14, 0.75)";
  g.fillRect(x - 3, y - 3, barWidth + 6, barHeight + 6);
  g.strokeStyle = "rgba(80, 200, 220, 0.4)";
  g.lineWidth = 1;
  g.strokeRect(x - 3, y - 3, barWidth + 6, barHeight + 6);

  const o2Ratio = oxygen / 100;
  g.fillStyle = o2Ratio > 0.2 ? "rgba(90, 240, 210, 0.9)" : "rgba(255, 90, 120, 0.9)";
  g.fillRect(x, y, barWidth * o2Ratio, barHeight);
}

function drawScene(g) {
  drawBackground(g);
  drawArtifacts(g);
  drawExit(g);
  drawPlayer(g);
  drawMonster(g);
  drawSonar(g);
  drawHUDOverlay(g);
}

function render() {
  pixelCtx.setTransform(1, 0, 0, 1, 0, 0);
  pixelCtx.clearRect(0, 0, pixelCanvas.width, pixelCanvas.height);
  pixelCtx.save();
  const scaleX = pixelCanvas.width / world.width;
  const scaleY = pixelCanvas.height / world.height;
  pixelCtx.scale(scaleX, scaleY);
  drawScene(pixelCtx);
  pixelCtx.restore();

  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(pixelCanvas, 0, 0, canvas.width, canvas.height);
}

let last = performance.now();
function loop(now) {
  const dt = Math.min(0.033, (now - last) / 1000);
  last = now;

  if (gameState === "playing") {
    updatePlayer(dt);
    updateMonster(dt);
    updateArtifacts();
    updateExit();
    updateOxygen(dt);
    updatePing(dt);
    updateBubbles(dt);
    updateHUD();
    checkLose();
  }

  render();
  requestAnimationFrame(loop);
}

window.addEventListener("keydown", (e) => {
  if (e.code === "Space") {
    if (gameState !== "playing") {
      gameState = "playing";
      oxygen = 100;
      artifacts.forEach(a => a.picked = false);
      exitBeacon.active = false;
      monster.target = null;
      hideOverlay();
      return;
    }
    if (pingTimer <= 0) onPing();
    e.preventDefault();
  } else {
    keys.add(e.key);
  }
});

window.addEventListener("keyup", (e) => {
  keys.delete(e.key);
});

// Mobile-friendly touch ping
canvas.addEventListener("pointerdown", () => {
  if (pingTimer <= 0 && gameState === "playing") onPing();
});

requestAnimationFrame(loop);
